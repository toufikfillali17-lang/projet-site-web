document.getElementById("resForm").addEventListener("submit", function(e) {
    e.preventDefault();
    window.location.href = "confirmation.html";
});
